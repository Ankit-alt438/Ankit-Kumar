package com.example.myproject.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "passwords")
data class PasswordEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val websiteName: String,
    val username: String,
    val encryptedPassword: String,
    val passwordIv: String,
    val encryptedNotes: String = "",
    val notesIv: String = "",
    val category: String = "General",
    val createdAt: Long = System.currentTimeMillis()
)
