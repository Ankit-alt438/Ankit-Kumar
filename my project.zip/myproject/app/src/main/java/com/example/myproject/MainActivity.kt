package com.example.myproject

import android.os.Bundle
import android.widget.Toast
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.biometric.BiometricPrompt
import androidx.compose.runtime.*
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.myproject.ui.*
import com.example.myproject.ui.screens.*
import com.example.myproject.ui.theme.MyProjectTheme

class MainActivity : FragmentActivity() {
    
    private var lastInteractionTime: Long = System.currentTimeMillis()
    private val timeoutMs: Long = 5 * 60 * 1000 // 5 minutes

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyProjectTheme {
                val viewModel: PasswordViewModel = viewModel()
                val navController = rememberNavController()
                
                // Determine start destination
                val startDestination = remember {
                    if (!viewModel.isRegistered()) {
                        "welcome"
                    } else if (!viewModel.isLoggedIn()) {
                        "login"
                    } else {
                        "home"
                    }
                }

                // Simple Auto-Logout logic on Resume
                LaunchedEffect(Unit) {
                    if (viewModel.isLoggedIn() && System.currentTimeMillis() - lastInteractionTime > timeoutMs) {
                        viewModel.logout()
                        navController.navigate("login") {
                            popUpTo(0)
                        }
                    }
                }

                NavHost(navController = navController, startDestination = startDestination) {
                    composable("welcome") {
                        WelcomeScreen(
                            onNext = { navController.navigate("setup") }
                        )
                    }
                    composable("setup") {
                        SetupScreen(
                            viewModel = viewModel,
                            onComplete = { 
                                navController.navigate("biometric_setup")
                            },
                            onLoginClick = {
                                navController.navigate("login")
                            }
                        )
                    }
                    composable("biometric_setup") {
                        BiometricSetupScreen(
                            onEnable = {
                                viewModel.setBiometricEnabled(true)
                                viewModel.generateAndSendOtp()
                                navController.navigate("otp") {
                                    popUpTo("setup") { inclusive = true }
                                }
                            },
                            onSkip = {
                                viewModel.setBiometricEnabled(false)
                                viewModel.generateAndSendOtp()
                                navController.navigate("otp") {
                                    popUpTo("setup") { inclusive = true }
                                }
                            }
                        )
                    }
                    composable("login") {
                        LoginScreen(
                            viewModel = viewModel,
                            onLoginSuccess = {
                                viewModel.generateAndSendOtp()
                                navController.navigate("otp") {
                                    popUpTo("login") { inclusive = true }
                                }
                            },
                            onBiometricLogin = {
                                showBiometricPrompt {
                                    viewModel.setLoggedIn(true)
                                    navController.navigate("home") {
                                        popUpTo("login") { inclusive = true }
                                    }
                                }
                            },
                            onRegisterClick = {
                                navController.navigate("setup")
                            }
                        )
                    }
                    composable("otp") {
                        OtpScreen(
                            viewModel = viewModel,
                            onVerify = {
                                viewModel.setLoggedIn(true)
                                navController.navigate("home") {
                                    popUpTo("otp") { inclusive = true }
                                }
                            },
                            onResend = {
                                Toast.makeText(this@MainActivity, "OTP Resent to your email", Toast.LENGTH_SHORT).show()
                            }
                        )
                    }
                    composable("home") {
                        HomeScreen(
                            viewModel = viewModel,
                            onAddClick = { navController.navigate("add_password") },
                            onToolsClick = { navController.navigate("tools") },
                            onProfileClick = { navController.navigate("profile") },
                            onEditClick = { id -> navController.navigate("edit_password/$id") },
                            onLogout = {
                                viewModel.logout()
                                navController.navigate("login") {
                                    popUpTo("home") { inclusive = true }
                                }
                            }
                        )
                    }
                    composable("add_password") {
                        AddPasswordScreen(
                            onBack = { navController.popBackStack() },
                            onSave = { website, user, pass, notes, cat ->
                                viewModel.addPassword(website, user, pass, notes, cat)
                                navController.popBackStack()
                            }
                        )
                    }
                    composable(
                        "edit_password/{id}",
                        arguments = listOf(navArgument("id") { type = NavType.StringType })
                    ) { backStackEntry ->
                        val id = backStackEntry.arguments?.getString("id") ?: return@composable
                        EditPasswordScreen(
                            passwordId = id,
                            viewModel = viewModel,
                            onBack = { navController.popBackStack() }
                        )
                    }
                    composable("tools") {
                        ToolsScreen(
                            onBack = { navController.popBackStack() },
                            onGeneratorClick = { navController.navigate("generator") }
                        )
                    }
                    composable("generator") {
                        PasswordGeneratorScreen(onBack = { navController.popBackStack() })
                    }
                    composable("profile") {
                        ProfileScreen(
                            viewModel = viewModel,
                            onBack = { navController.popBackStack() },
                            onLogout = {
                                viewModel.logout()
                                navController.navigate("login") {
                                    popUpTo("home") { inclusive = true }
                                }
                            }
                        )
                    }
                }
            }
        }
    }

    override fun onUserInteraction() {
        super.onUserInteraction()
        lastInteractionTime = System.currentTimeMillis()
    }

    private fun showBiometricPrompt(onSuccess: () -> Unit) {
        val executor = ContextCompat.getMainExecutor(this)
        val biometricPrompt = BiometricPrompt(this, executor,
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    super.onAuthenticationSucceeded(result)
                    onSuccess()
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    super.onAuthenticationError(errorCode, errString)
                    Toast.makeText(applicationContext, "Auth error: $errString", Toast.LENGTH_SHORT).show()
                }
            })

        val promptInfo = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Biometric login")
            .setSubtitle("Log in using your biometric credential")
            .setNegativeButtonText("Use master password")
            .build()

        biometricPrompt.authenticate(promptInfo)
    }
}
