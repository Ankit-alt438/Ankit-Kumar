package com.example.myproject.data

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

class UserPreferences(context: Context) {
    private val masterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    private val sharedPreferences = EncryptedSharedPreferences.create(
        context,
        "user_prefs",
        masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    fun saveMasterPassword(password: String) {
        sharedPreferences.edit().putString("master_password", password).apply()
    }

    fun getMasterPassword(): String? {
        return sharedPreferences.getString("master_password", null)
    }

    fun saveEmail(email: String) {
        sharedPreferences.edit().putString("user_email", email).apply()
    }

    fun getEmail(): String? {
        return sharedPreferences.getString("user_email", null)
    }

    fun saveDisplayName(name: String) {
        sharedPreferences.edit().putString("display_name", name).apply()
    }

    fun getDisplayName(): String? {
        return sharedPreferences.getString("display_name", "Alex Barker")
    }

    fun saveProfilePicturePath(path: String) {
        sharedPreferences.edit().putString("profile_picture_path", path).apply()
    }

    fun getProfilePicturePath(): String? {
        return sharedPreferences.getString("profile_picture_path", null)
    }

    fun setBiometricEnabled(enabled: Boolean) {
        sharedPreferences.edit().putBoolean("biometric_enabled", enabled).apply()
    }

    fun isBiometricEnabled(): Boolean {
        return sharedPreferences.getBoolean("biometric_enabled", false)
    }

    fun isLoggedIn(): Boolean {
        return sharedPreferences.getBoolean("is_logged_in", false)
    }

    fun setLoggedIn(loggedIn: Boolean) {
        sharedPreferences.edit().putBoolean("is_logged_in", loggedIn).apply()
    }
}
