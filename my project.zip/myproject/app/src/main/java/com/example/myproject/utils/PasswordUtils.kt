package com.example.myproject.utils

import kotlin.random.Random

object PasswordUtils {
    fun generatePassword(
        length: Int = 16,
        upper: Boolean = true,
        lower: Boolean = true,
        num: Boolean = true,
        sym: Boolean = true
    ): String {
        val charPool = StringBuilder().apply {
            if (upper) append("ABCDEFGHIJKLMNOPQRSTUVWXYZ")
            if (lower) append("abcdefghijklmnopqrstuvwxyz")
            if (num) append("0123456789")
            if (sym) append("!@#$%^&*()-_=+[]{}|;:,.<>?")
        }.toString()

        if (charPool.isEmpty()) return ""

        return (1..length)
            .map { Random.nextInt(0, charPool.length).let { charPool[it] } }
            .joinToString("")
    }
}
