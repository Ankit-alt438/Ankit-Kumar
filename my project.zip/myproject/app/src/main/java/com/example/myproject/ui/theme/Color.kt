package com.example.myproject.ui.theme

import androidx.compose.ui.graphics.Color

val DarkBackground = Color(0xFF0F0E17)
val CardBackground = Color(0xFF1B1A23)
val PrimaryPurple = Color(0xFF7F3DFF)
val AccentPurple = Color(0xFFB39DDB)
val TextPrimary = Color(0xFFFFFFFF)
val TextSecondary = Color(0xFF94A3B8)
val ErrorRed = Color(0xFFE53935)
val SuccessGreen = Color(0xFF4CAF50)

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)
