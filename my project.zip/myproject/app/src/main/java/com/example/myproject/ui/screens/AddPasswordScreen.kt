package com.example.myproject.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.myproject.ui.PasswordViewModel
import com.example.myproject.ui.components.CustomLabelTextField
import com.example.myproject.utils.PasswordUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddPasswordScreen(
    onBack: () -> Unit,
    onSave: (String, String, String, String, String) -> Unit
) {
    var website by remember { mutableStateOf("") }
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("General") }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background,
                    titleContentColor = Color.White
                ),
                title = { Text("Add a Password", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                actions = {
                    IconButton(
                        onClick = { onSave(website, username, password, notes, category) },
                        enabled = website.isNotEmpty() && username.isNotEmpty() && password.isNotEmpty()
                    ) {
                        Icon(Icons.Default.Save, contentDescription = "Save", tint = if (website.isNotEmpty() && username.isNotEmpty() && password.isNotEmpty()) Color.White else Color.Gray)
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(20.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            CustomLabelTextField(label = "Website/App Name", value = website, onValueChange = { website = it }, placeholder = "e.g. facebook.com")
            CustomLabelTextField(label = "Username/Email", value = username, onValueChange = { username = it }, placeholder = "e.g. user@email.com")
            
            Column {
                Text(text = "Password", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("Enter password", color = Color.Gray) },
                    trailingIcon = {
                        IconButton(onClick = { password = PasswordUtils.generatePassword() }) {
                            Icon(Icons.Default.Refresh, contentDescription = "Generate", tint = MaterialTheme.colorScheme.primary)
                        }
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        unfocusedContainerColor = MaterialTheme.colorScheme.surface,
                        focusedContainerColor = MaterialTheme.colorScheme.surface,
                        unfocusedBorderColor = Color.Transparent,
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White
                    ),
                    shape = RoundedCornerShape(12.dp)
                )
            }

            CustomLabelTextField(label = "Category", value = category, onValueChange = { category = it }, placeholder = "e.g. Apps, Banking, Email, Notes")
            CustomLabelTextField(label = "Notes", value = notes, onValueChange = { notes = it }, placeholder = "Add some notes...", isSingleLine = false)

            Spacer(modifier = Modifier.height(20.dp))
            
            Button(
                onClick = { onSave(website, username, password, notes, category) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                enabled = website.isNotEmpty() && username.isNotEmpty() && password.isNotEmpty()
            ) {
                Text("Save Credentials", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}
