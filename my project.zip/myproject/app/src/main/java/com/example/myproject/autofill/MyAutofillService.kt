package com.example.myproject.autofill

import android.app.assist.AssistStructure
import android.os.CancellationSignal
import android.service.autofill.*
import android.view.autofill.AutofillId
import android.view.autofill.AutofillValue
import android.widget.RemoteViews
import com.example.myproject.data.AppDatabase
import com.example.myproject.data.PasswordEntity
import com.example.myproject.security.CryptoManager
import kotlinx.coroutines.runBlocking
import java.util.*

class MyAutofillService : AutofillService() {

    private val cryptoManager = CryptoManager()

    override fun onFillRequest(
        request: FillRequest,
        cancellationSignal: CancellationSignal,
        callback: FillCallback
    ) {
        val structure = request.fillContexts.last().structure
        val packageName = structure.activityComponent.packageName
        
        val database = AppDatabase.getDatabase(this)
        val passwords: List<PasswordEntity> = runBlocking {
            database.passwordDao().getPasswordsSync()
        }

        val fields = findAutofillFields(structure)
        if (fields.usernameId == null || fields.passwordId == null) {
            callback.onSuccess(null)
            return
        }

        // Simple matching logic: find a saved password where websiteName contains the package name
        val matchingCredential = passwords.find { entity ->
            packageName.contains(entity.websiteName, ignoreCase = true) || 
            entity.websiteName.contains(packageName, ignoreCase = true)
        }

        if (matchingCredential != null) {
            val decryptedPassword = try {
                cryptoManager.decrypt(matchingCredential.encryptedPassword, matchingCredential.passwordIv)
            } catch (e: Exception) {
                ""
            }
            
            if (decryptedPassword.isNotEmpty()) {
                val response = FillResponse.Builder()
                    .addDataset(
                        Dataset.Builder()
                            .setValue(fields.usernameId!!, AutofillValue.forText(matchingCredential.username), 
                                createPresentation(matchingCredential.username))
                            .setValue(fields.passwordId!!, AutofillValue.forText(decryptedPassword), 
                                createPresentation("Password for ${matchingCredential.username}"))
                            .build()
                    )
                    .build()
                callback.onSuccess(response)
            } else {
                callback.onSuccess(null)
            }
        } else {
            callback.onSuccess(null)
        }
    }

    override fun onSaveRequest(request: SaveRequest, callback: SaveCallback) {
        callback.onSuccess()
    }

    private fun createPresentation(text: String): RemoteViews {
        val presentation = RemoteViews(packageName, android.R.layout.simple_list_item_1)
        presentation.setTextViewText(android.R.id.text1, text)
        return presentation
    }

    private fun findAutofillFields(structure: AssistStructure): AutofillFields {
        val fields = AutofillFields()
        val nodes = Stack<AssistStructure.ViewNode>()
        for (i in 0 until structure.windowNodeCount) {
            nodes.push(structure.getWindowNodeAt(i).rootViewNode)
        }

        while (nodes.isNotEmpty()) {
            val node = nodes.pop()
            val hints = node.autofillHints
            if (hints != null) {
                if (hints.contains("username") || hints.contains("emailAddress")) {
                    fields.usernameId = node.autofillId
                } else if (hints.contains("password")) {
                    fields.passwordId = node.autofillId
                }
            }
            
            val idEntry = node.idEntry
            if (idEntry != null) {
                if (fields.usernameId == null && (idEntry.contains("user", true) || idEntry.contains("email", true))) {
                    fields.usernameId = node.autofillId
                }
                if (fields.passwordId == null && idEntry.contains("password", true)) {
                    fields.passwordId = node.autofillId
                }
            }

            for (i in 0 until node.childCount) {
                nodes.push(node.getChildAt(i))
            }
        }
        return fields
    }

    class AutofillFields {
        var usernameId: AutofillId? = null
        var passwordId: AutofillId? = null
    }
}
