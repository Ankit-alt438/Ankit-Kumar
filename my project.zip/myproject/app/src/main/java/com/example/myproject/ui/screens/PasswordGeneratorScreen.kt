package com.example.myproject.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import kotlin.random.Random

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PasswordGeneratorScreen(onBack: () -> Unit) {
    var passwordLength by remember { mutableStateOf(16f) }
    var includeUppercase by remember { mutableStateOf(true) }
    var includeLowercase by remember { mutableStateOf(true) }
    var includeNumbers by remember { mutableStateOf(true) }
    var includeSymbols by remember { mutableStateOf(true) }
    
    var generatedPassword by remember { mutableStateOf("") }
    val clipboardManager = LocalClipboardManager.current

    LaunchedEffect(passwordLength, includeUppercase, includeLowercase, includeNumbers, includeSymbols) {
        generatedPassword = generatePassword(
            passwordLength.toInt(),
            includeUppercase,
            includeLowercase,
            includeNumbers,
            includeSymbols
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Password Generator") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(24.dp)
        ) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = generatedPassword,
                        style = MaterialTheme.typography.headlineMedium,
                        modifier = Modifier.padding(vertical = 16.dp)
                    )
                    Row {
                        IconButton(onClick = {
                            generatedPassword = generatePassword(
                                passwordLength.toInt(),
                                includeUppercase,
                                includeLowercase,
                                includeNumbers,
                                includeSymbols
                            )
                        }) {
                            Icon(Icons.Default.Refresh, contentDescription = "Regenerate")
                        }
                        IconButton(onClick = {
                            clipboardManager.setText(AnnotatedString(generatedPassword))
                        }) {
                            Icon(Icons.Default.ContentCopy, contentDescription = "Copy")
                        }
                    }
                }
            }

            Column {
                Text(text = "Length: ${passwordLength.toInt()}")
                Slider(
                    value = passwordLength,
                    onValueChange = { passwordLength = it },
                    valueRange = 8f..32f,
                    steps = 24
                )
            }

            ToggleOption("Include Uppercase (A-Z)", includeUppercase) { includeUppercase = it }
            ToggleOption("Include Lowercase (a-z)", includeLowercase) { includeLowercase = it }
            ToggleOption("Include Numbers (0-9)", includeNumbers) { includeNumbers = it }
            ToggleOption("Include Symbols (!@#$)", includeSymbols) { includeSymbols = it }
        }
    }
}

@Composable
fun ToggleOption(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label)
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

fun generatePassword(
    length: Int,
    upper: Boolean,
    lower: Boolean,
    num: Boolean,
    sym: Boolean
): String {
    val charPool = StringBuilder().apply {
        if (upper) append("ABCDEFGHIJKLMNOPQRSTUVWXYZ")
        if (lower) append("abcdefghijklmnopqrstuvwxyz")
        if (num) append("0123456789")
        if (sym) append("!@#$%^&*()-_=+[]{}|;:,.<>?")
    }.toString()

    if (charPool.isEmpty()) return ""

    return (1..length)
        .map { Random.nextInt(0, charPool.length).let { charPool[it] } }
        .joinToString("")
}
