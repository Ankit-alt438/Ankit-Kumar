package com.example.myproject.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.myproject.ui.PasswordViewModel
import com.example.myproject.ui.components.CustomLabelTextField

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditPasswordScreen(
    passwordId: String,
    viewModel: PasswordViewModel,
    onBack: () -> Unit
) {
    val passwords by viewModel.passwords.collectAsState()
    val passwordEntity = passwords.find { it.id == passwordId } ?: return

    var website by remember { mutableStateOf(passwordEntity.websiteName) }
    var username by remember { mutableStateOf(passwordEntity.username) }
    var password by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var category by remember { mutableStateOf(passwordEntity.category) }

    // Decrypt existing values on first load
    LaunchedEffect(passwordEntity) {
        password = viewModel.decryptPassword(passwordEntity.encryptedPassword, passwordEntity.passwordIv)
        notes = viewModel.decryptPassword(passwordEntity.encryptedNotes, passwordEntity.notesIv)
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background,
                    titleContentColor = Color.White
                ),
                title = { Text("Edit Password", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                actions = {
                    IconButton(
                        onClick = { 
                            viewModel.updatePassword(passwordId, website, username, password, notes, category)
                            onBack()
                        },
                        enabled = website.isNotEmpty() && username.isNotEmpty() && password.isNotEmpty()
                    ) {
                        Icon(Icons.Default.Save, contentDescription = "Save", tint = Color.White)
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(20.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            CustomLabelTextField(label = "Website/App Name", value = website, onValueChange = { website = it }, placeholder = "e.g. facebook.com")
            CustomLabelTextField(label = "Username/Email", value = username, onValueChange = { username = it }, placeholder = "e.g. user@email.com")
            CustomLabelTextField(label = "Password", value = password, onValueChange = { password = it }, placeholder = "Enter password")
            CustomLabelTextField(label = "Category", value = category, onValueChange = { category = it }, placeholder = "e.g. Social, Banking")
            CustomLabelTextField(label = "Notes", value = notes, onValueChange = { notes = it }, placeholder = "Add some notes...", isSingleLine = false)

            Spacer(modifier = Modifier.height(20.dp))
            
            Button(
                onClick = { 
                    viewModel.updatePassword(passwordId, website, username, password, notes, category)
                    onBack()
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                enabled = website.isNotEmpty() && username.isNotEmpty() && password.isNotEmpty()
            ) {
                Text("Update Credentials", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}
