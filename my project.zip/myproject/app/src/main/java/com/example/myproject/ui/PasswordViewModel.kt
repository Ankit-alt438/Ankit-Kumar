package com.example.myproject.ui

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.myproject.data.*
import com.example.myproject.security.CryptoManager
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.util.*

class PasswordViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: PasswordRepository
    private val cryptoManager = CryptoManager()
    private val userPreferences = UserPreferences(application)
    private val auth: FirebaseAuth = Firebase.auth
    private val db: FirebaseFirestore = Firebase.firestore

    private val _searchQuery = MutableStateFlow("")
    val searchQuery = _searchQuery.asStateFlow()

    private val _selectedCategory = MutableStateFlow<String?>(null)
    val selectedCategory = _selectedCategory.asStateFlow()

    private val _generatedOtp = MutableStateFlow<String?>(null)
    val generatedOtp = _generatedOtp.asStateFlow()

    private val _authState = MutableStateFlow<AuthState>(AuthState.Idle)
    val authState = _authState.asStateFlow()

    private val _displayName = MutableStateFlow(userPreferences.getDisplayName() ?: "Alex Barker")
    val displayName = _displayName.asStateFlow()

    private val _profilePicturePath = MutableStateFlow(userPreferences.getProfilePicturePath())
    val profilePicturePath = _profilePicturePath.asStateFlow()

    init {
        val database = AppDatabase.getDatabase(application)
        repository = PasswordRepository(database.passwordDao())
        
        if (auth.currentUser != null) {
            syncFromFirestore()
        }
    }

    val passwords: StateFlow<List<PasswordEntity>> = combine(
        searchQuery.debounce(300),
        selectedCategory,
        repository.allPasswords
    ) { query, category, all ->
        all.filter { 
            (category == null || it.category.equals(category, ignoreCase = true)) &&
            (query.isEmpty() || it.websiteName.contains(query, ignoreCase = true) || it.username.contains(query, ignoreCase = true))
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Calculated Stats
    val stats = repository.allPasswords.map { list ->
        val decryptedPasswords = list.map { decryptPassword(it.encryptedPassword, it.passwordIv) }
        val strong = decryptedPasswords.count { it.length >= 12 && it.any { c -> !c.isLetterOrDigit() } }
        val weak = decryptedPasswords.count { it.length < 8 }
        val reused = decryptedPasswords.groupBy { it }.filter { it.value.size > 1 }.values.flatten().size
        VaultStats(strong.toString(), reused.toString().padStart(2, '0'), weak.toString(), "00")
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), VaultStats("0", "00", "0", "00"))

    private fun syncFromFirestore() {
        val userId = auth.currentUser?.uid ?: return
        viewModelScope.launch {
            try {
                val snapshot = db.collection("users").document(userId).collection("passwords").get().await()
                snapshot.documents.forEach { doc ->
                    val data = doc.data ?: return@forEach
                    val entity = PasswordEntity(
                        id = doc.id,
                        websiteName = data["websiteName"] as? String ?: "Unknown",
                        username = data["username"] as? String ?: "Unknown",
                        encryptedPassword = data["encryptedPassword"] as? String ?: "",
                        passwordIv = data["passwordIv"] as? String ?: "",
                        encryptedNotes = data["encryptedNotes"] as? String ?: "",
                        notesIv = data["notesIv"] as? String ?: "",
                        category = data["category"] as? String ?: "General",
                        createdAt = (data["createdAt"] as? Long) ?: System.currentTimeMillis()
                    )
                    repository.insert(entity)
                }
            } catch (e: Exception) {
                Log.e("FirebaseSync", "Sync failed", e)
            }
        }
    }

    fun onSearchQueryChange(query: String) {
        _searchQuery.value = query
    }

    fun selectCategory(category: String?) {
        _selectedCategory.value = if (_selectedCategory.value == category) null else category
    }

    fun addPassword(website: String, username: String, passwordRaw: String, notes: String, category: String) {
        viewModelScope.launch {
            val (encryptedPass, passIv) = cryptoManager.encrypt(passwordRaw)
            val (encryptedNotes, notesIv) = if (notes.isNotEmpty()) {
                cryptoManager.encrypt(notes)
            } else {
                "" to ""
            }

            val entity = PasswordEntity(
                websiteName = website,
                username = username,
                encryptedPassword = encryptedPass,
                passwordIv = passIv,
                encryptedNotes = encryptedNotes,
                notesIv = notesIv,
                category = category
            )
            repository.insert(entity)
            
            val userId = auth.currentUser?.uid
            if (userId != null) {
                val remoteData = hashMapOf(
                    "websiteName" to website,
                    "username" to username,
                    "encryptedPassword" to encryptedPass,
                    "passwordIv" to passIv,
                    "encryptedNotes" to encryptedNotes,
                    "notesIv" to notesIv,
                    "category" to category,
                    "createdAt" to entity.createdAt
                )
                db.collection("users").document(userId).collection("passwords")
                    .document(entity.id)
                    .set(remoteData)
            }
        }
    }

    fun updatePassword(passwordId: String, website: String, username: String, passwordRaw: String, notes: String, category: String) {
        viewModelScope.launch {
            val (encryptedPass, passIv) = cryptoManager.encrypt(passwordRaw)
            val (encryptedNotes, notesIv) = if (notes.isNotEmpty()) {
                cryptoManager.encrypt(notes)
            } else {
                "" to ""
            }

            val original = passwords.value.find { it.id == passwordId } ?: return@launch
            val updated = original.copy(
                websiteName = website,
                username = username,
                encryptedPassword = encryptedPass,
                passwordIv = passIv,
                encryptedNotes = encryptedNotes,
                notesIv = notesIv,
                category = category
            )
            repository.update(updated)
            
            val userId = auth.currentUser?.uid
            if (userId != null) {
                val remoteData = hashMapOf(
                    "websiteName" to website,
                    "username" to username,
                    "encryptedPassword" to encryptedPass,
                    "passwordIv" to passIv,
                    "encryptedNotes" to encryptedNotes,
                    "notesIv" to notesIv,
                    "category" to category,
                    "createdAt" to updated.createdAt
                )
                db.collection("users").document(userId).collection("passwords")
                    .document(updated.id)
                    .set(remoteData)
            }
        }
    }

    fun decryptPassword(encrypted: String, iv: String): String {
        if (encrypted.isEmpty() || iv.isEmpty()) return ""
        return try {
            cryptoManager.decrypt(encrypted, iv)
        } catch (e: Exception) {
            "Error Decrypting"
        }
    }

    fun deletePassword(password: PasswordEntity) {
        viewModelScope.launch {
            repository.delete(password)
            
            val userId = auth.currentUser?.uid
            if (userId != null) {
                db.collection("users").document(userId).collection("passwords")
                    .document(password.id)
                    .delete()
            }
        }
    }

    // Firebase Auth
    fun registerWithFirebase(email: String, password: String) {
        viewModelScope.launch {
            _authState.value = AuthState.Loading
            try {
                auth.createUserWithEmailAndPassword(email, password).await()
                userPreferences.saveEmail(email)
                userPreferences.saveMasterPassword(password)
                _authState.value = AuthState.Success
            } catch (e: Exception) {
                _authState.value = AuthState.Error(e.message ?: "Registration failed")
            }
        }
    }

    fun loginWithFirebase(email: String, password: String) {
        viewModelScope.launch {
            _authState.value = AuthState.Loading
            try {
                auth.signInWithEmailAndPassword(email, password).await()
                userPreferences.saveEmail(email)
                userPreferences.saveMasterPassword(password)
                syncFromFirestore()
                _authState.value = AuthState.Success
            } catch (e: Exception) {
                _authState.value = AuthState.Error(e.message ?: "Login failed")
            }
        }
    }

    fun logout() {
        auth.signOut()
        setLoggedIn(false)
        _authState.value = AuthState.Idle
    }

    fun isRegistered() = auth.currentUser != null || userPreferences.getMasterPassword() != null
    fun isLoggedIn() = userPreferences.isLoggedIn()
    fun setLoggedIn(loggedIn: Boolean) = userPreferences.setLoggedIn(loggedIn)
    fun getEmail() = auth.currentUser?.email ?: userPreferences.getEmail()
    
    fun checkPassword(password: String) = userPreferences.getMasterPassword() == password
    fun setBiometricEnabled(enabled: Boolean) = userPreferences.setBiometricEnabled(enabled)
    fun isBiometricEnabled() = userPreferences.isBiometricEnabled()

    fun generateAndSendOtp() {
        val otp = (100000..999999).random().toString()
        _generatedOtp.value = otp
        val email = getEmail()
        // Log specifically so user can see it in Logcat
        Log.d("OTP_SERVICE", "--------------------------------------")
        Log.d("OTP_SERVICE", "YOUR OTP CODE IS: $otp")
        Log.d("OTP_SERVICE", "Sent to: $email")
        Log.d("OTP_SERVICE", "--------------------------------------")
    }

    fun verifyOtp(enteredOtp: String): Boolean {
        return enteredOtp == _generatedOtp.value
    }

    fun updateProfile(name: String, picturePath: String?) {
        userPreferences.saveDisplayName(name)
        _displayName.value = name
        picturePath?.let {
            userPreferences.saveProfilePicturePath(it)
            _profilePicturePath.value = it
        }
    }

    fun clearAuthState() {
        _authState.value = AuthState.Idle
    }
}

data class VaultStats(val strong: String, val reused: String, val weak: String, val compromised: String)

sealed class AuthState {
    object Idle : AuthState()
    object Loading : AuthState()
    object Success : AuthState()
    data class Error(val message: String) : AuthState()
}
